import fetch from 'node-fetch'
import axios from 'axios'
import cheerio from 'cheerio'



let handler = async (m, { conn, args }) => {
         if (!args[0]) return m.reply(m.chat, Func.example(isPrefix, command, 'https://vm.tiktok.com/ZSR7c5G6y/'), m)
         if (!args[0].match('tiktok.com')) return client.reply(m.chat, global.status.invalid, m)
         client.sendReact(m.chat, '🕒', m.key)
         let old = new Date()
         let json = await Api.tiktok(Func.ttFixed(args[0]))
         if (!json.status) return m.reply(m.chat, Func.jsonFormat(json), m)
         if (command == 'tiktok' || command == 'tt') return conn.sendButton(m.chat, json.data.video, `Here`, ``, m,)
}

handler.help = ['tiktok']
handler.tags = ['downloader']
handler.command = ['tiktok', 'tt']

export default handler
