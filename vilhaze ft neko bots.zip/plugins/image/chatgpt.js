let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*This command generates image from texts*\n\n*—◉ 𝙴xample usage*\n*◉ ${usedPrefix + command} Neko*\n*◉ ${usedPrefix + command} Tokyo*`
try {
m.reply('*Processing image *')
let tiores = await conn.getFile(`https://api.lolhuman.xyz/api/dall-e?apikey=${lolkeysapi}&text=${text}`)
await conn.sendFile(m.chat, tiores.data, null, null, m)

}

handler.help = ['aiimg']
handler.tags = ['image']
handler.command = ['chatgpt2', 'ai2', 'dalle', 'aimg']

export default handler