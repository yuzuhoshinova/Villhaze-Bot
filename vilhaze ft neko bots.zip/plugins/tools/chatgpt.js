import fetch from 'node-fetch'

let handler = async (m, { text }) => {
   if (!text) return m.reply('Ingrese un Texto')
let tiores = await fetch(`https://api.lolhuman.xyz/api/openai?apikey=BrunoSobrino&text=${text}&user=user-unique-id`)
let hasil = await tiores.json()
m.reply(`${hasil.result}`.trim())

}

handler.help = ['chatgpt']
handler.tags = ['tool']
handler.command = ['chatgpt', 'ai', 'vill', 'ze']

export default handler