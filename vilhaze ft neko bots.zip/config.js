import Connection from './lib/connection.js'
import { watchFile, unwatchFile, readFileSync } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
   ['62881026097315', '「Anisphia Wynn Palettia」', true],
   ['62831193186539', 'Euphyllia Fez Palettia', true]
]

global.mods = []
global.prems = []

global.APIs = {
   nrtm: 'https://nurutomo.herokuapp.com',
   bg: 'http://bochil.ddns.net',
   xteam: 'https://api.xteam.xyz',
   zahir: 'https://zahirr-web.herokuapp.com',
   zeks: 'https://api.zeks.xyz',
   pencarikode: 'https://pencarikode.xyz',
   LeysCoder: 'https://leyscoders-api.herokuapp.com'
}

global.APIKeys = {
   'https://api.xteam.xyz': 'd90a9e986e18778b',
   'https://zahirr-web.herokuapp.com': 'zahirgans',
   'https://api.zeks.xyz': 'apivinz',
   'https://pencarikode.xyz': 'pais',
   'https://leyscoders-api.herokuapp.com': 'dappakntlll'
}

global.imgbot = {
   neko1: readFileSync('./src/image/neko-1.jpg'),
   neko2: readFileSync('./src/image/neko-2.jpg'),
   neko3: readFileSync('./src/image/neko-3.jpg'),
   noprofile: readFileSync('./src/image/no-profile.jpg'),
   noprofileurl: 'https://i.ibb.co/fp6t21w/avatar.jpg',
}

global.textbot = {
   title: 'ㅤ·ㅤVillhaze By Ywxzyyㅤ·ㅤ',
   footer: 'Kono Sora wa Utsukushi Desu-ne..',
}

global.fakebot = {
   gif(text = null, img = null) {
      return { key: { participant: '0@s.whatsapp.net', remoteJid: '62881026097315-1621306547@g.us', fromMe: false, id: 'BAE5D0B72A69AF85' }, message: { videoMessage: { title: null, h: 'Hmm', seconds: 999999999, gifPlayback: true, caption: text, jpegThumbnail: img }}}
   }
}

// Sticker WM
global.packname = '\nVillhaze'
global.author = '\nヴィルヘイズ'

global.wmbot = {
   name: 'Villhaze',
   author: '\n\n\n .',
}

global.multiplier = 200

global.rpg = {
   emoticon(string) {
      string = string.toLowerCase()
      let emot = {
         role: '🏅',
         level: '🧬',
         limit: '🌌',
         health: '❤️',
         exp: '✉️',
         money: '💵',
         potion: '🥤',
         diamond: '💎',
         wood: '🪵',
         rock: '🪨',
         iron: '🔩',
         gold: '👑',
         emerald: '💚'
      }
      let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
      if (!results.length) return ''
      else return emot[results[0][0]]
   },
   role(level) {
      level = parseInt(level)
      if (isNaN(level)) return { name: '', level: '' }
      const role = [
         { name: 'Bronze I', level: 0 }, { name: 'Bronze II', level: 6 }, { name: 'Bronze III', level: 12 },
         { name: 'Platinum I', level: 18 }, { name: 'Platinum II', level: 24 }, { name: 'Platinum III', level: 30 },
         { name: 'Zenith I', level: 36 }, { name: 'Zenith II', level: 42 }, { name: 'Zenith III', level: 48 },
         { name: 'Xryzz I', level: 45 }, { name: 'Xryzz II', level: 54 }, { name: 'Xryzz III', level: 60 },
         { name: 'Mthicxz I', level: 66 }, { name: 'Mthicxz II', level: 72 }, { name: 'Mthicxz III', level: 78 },
         { name: 'Zynxxs I', level: 84 }, { name: 'Zynxxs II', level: 90 }, { name: 'Zynxxs III', level: 96 },
         { name: 'Immeasurable', level: 102 }, { name: 'Immeasurable', level: 1000 },
      ]
      return role.reverse().find(role => level >= role.level)
   }
}

// Games mini Database
global.game = {
   slot: {},
   math: {},
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  Connection.conn.logger.info("Update 'config.js'")
  import(`${file}?update=${Date.now()}`)
})
